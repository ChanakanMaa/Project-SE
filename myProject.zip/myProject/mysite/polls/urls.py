from django.urls import path

from . import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('login/', views.login, name='login'),
    path('regis/', views.regis, name='regis'),
    path('profile/', views.profile, name='profile'),
    path('home/', views.home, name='home'),
    path('upload/', views.upload, name='upload'),
    path('refer_assess/', views.refer_assess, name='refer_assess'),
    path('payment/', views.payment, name='payment'),
    path('status/', views.status, name='status'),
    path('tran_review/', views.tran_review, name='tran_review'),
    path('payment_2/', views.payment, name='payment_2'),
    path('offer_1/', views.offer_1, name='offer_1'),
    path('offer_2/', views.offer_2, name='offer_2'),
    path('offer_3/', views.offer_3, name='offer_3'),
    path('review/', views.review, name='review'),
    path('cancel/', views.cancel, name='cancel'),
    path('finish/', views.finish, name='finish'),
    path('tran_status/', views.tran_status, name='tran_status'),
    path('tran_work/', views.tran_work, name='tran_work'),
]
