from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.template import loader


def index(request):
    template = loader.get_template("polls/home.html")
    return HttpResponse(template.render())
   # return render(request, template_name='polls/home.html')

#def login(request):
 #   return render(request, template_name='polls/login.html')
def login(request):
    template = loader.get_template("polls/login.html")
    return HttpResponse(template.render())

def regis(request):
    template = loader.get_template("polls/regis.html")
    return HttpResponse(template.render())

def profile(request):
    template = loader.get_template("polls/profile.html")
    return HttpResponse(template.render())

def home(request):
    template = loader.get_template("polls/home.html")
    return HttpResponse(template.render())

def upload(request):
    template = loader.get_template("polls/upload_assess.html")
    return HttpResponse(template.render())

def refer_assess(request):
    template = loader.get_template("polls/refer_assess.html")
    return HttpResponse(template.render())

def payment(request):
    template = loader.get_template("polls/payment.html")
    return HttpResponse(template.render())

def payment_2(request):
    template = loader.get_template("polls/payment_2.html")
    return HttpResponse(template.render())

def status(request):
    template = loader.get_template("polls/status.html")
    return HttpResponse(template.render())

def tran_review(request):
    template = loader.get_template("polls/profile_tran_review.html")
    return HttpResponse(template.render())

def offer_1(request):
    template = loader.get_template("polls/offer_price.html")
    return HttpResponse(template.render())

def offer_2(request):
    template = loader.get_template("polls/offer_price2.html")
    return HttpResponse(template.render())

def offer_3(request):
    template = loader.get_template("polls/offer_price3.html")
    return HttpResponse(template.render())

def review(request):
    template = loader.get_template("polls/review.html")
    return HttpResponse(template.render())

def cancel(request):
    template = loader.get_template("polls/status_cancel.html")
    return HttpResponse(template.render())

def finish(request):
    template = loader.get_template("polls/status_finish.html")
    return HttpResponse(template.render())

def tran_status(request):
    template = loader.get_template("polls/tran_status.html")
    return HttpResponse(template.render())

def tran_work(request):
    template = loader.get_template("polls/tran_work.html")
    return HttpResponse(template.render())